function sortTableByTitle() {
    let table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("projectsTable");
    switching = true;
    // Loop until no switching has been done:
    while (switching) {
        switching = false;
        rows = table.rows;
        // Loop through all table rows (except the first, which contains table headers):
        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            // Compare the two elements:
            x = rows[i].getElementsByTagName("TD")[0];
            y = rows[i + 1].getElementsByTagName("TD")[0];
            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                shouldSwitch = true;
                break;
            }
        }
        if (shouldSwitch) {
            // If a switch has been marked, make the switch and mark that a switch has been done:
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}

function sortTableByLanguage() {
    let table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("projectsTable");
    switching = true;
    while (switching) {
        switching = false;
        rows = table.rows;
        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[1];
            y = rows[i + 1].getElementsByTagName("TD")[1];
            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                shouldSwitch = true;
                break;
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
        }
    }
}
function showHome() {
    document.getElementById('home').style.display = 'block';
    document.getElementById('portfolio').style.display = 'none';
}

function showPortfolio() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('portfolio').style.display = 'block';
}
